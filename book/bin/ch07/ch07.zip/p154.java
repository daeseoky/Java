package ch07;

public class p154 {
	public static void main(String[] args) {
		
		Param p = new Param();
		//p.add(10.5, 5.5); //����
		
		p.add((int)10.5, (int)5.5);
		
	}

}

